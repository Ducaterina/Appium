package com.appium;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.offset.PointOption;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Day3RadioButtons {

  private AndroidDriver driver;

  @Before
  public void setUp() throws MalformedURLException {
    DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
    desiredCapabilities.setCapability("platformName", "Android");
    desiredCapabilities.setCapability("appium:platformVersion", "11");
    desiredCapabilities.setCapability("appium:deviceName", "Android SDK built for x86");
    desiredCapabilities.setCapability("appium:appPackage", "io.appium.android.apis");
    desiredCapabilities.setCapability("appium:appActivity", "io.appium.android.apis.ApiDemos");
    desiredCapabilities.setCapability("appium:ensureWebviewsHavePages", true);
    desiredCapabilities.setCapability("appium:nativeWebScreenshot", true);
    desiredCapabilities.setCapability("appium:newCommandTimeout", 3600);
    desiredCapabilities.setCapability("appium:connectHardwareKeyboard", true);

    URL remoteUrl = new URL("http://localhost:4723/wd/hub");

    driver = new AndroidDriver(remoteUrl, desiredCapabilities);
  }

  public void Views() {
	  MobileElement el1 = (MobileElement) driver.findElementByAccessibilityId("Views");
	    el1.click();
  }
  
  public void Scroll() {
	  (new TouchAction(driver))
      .press(PointOption.point(872, 2417))
      .moveTo(PointOption.point(872, 796))
      .release()
      .perform();
    (new TouchAction(driver))
      .press(PointOption.point(880, 2152))
      .moveTo(PointOption.point(846, 1099))
      .release()
      .perform();
    
  }
  
  public void RadioButtons() throws InterruptedException {
	  	MobileElement el2 = (MobileElement) driver.findElementByAccessibilityId("Radio Group");
	    el2.click();
	    
	    MobileElement el3 = (MobileElement) driver.findElementByAccessibilityId("Lunch");
	    String isChecked = el3.getAttribute("checked");
	    System.out.println("Lunch is checked by default? ="+isChecked);
	    
	    MobileElement el4 = (MobileElement) driver.findElementByAccessibilityId("Breakfast");
	    
	    String isChecked1 = el4.getAttribute("checked");
	    System.out.println("Breakfast is checked? ="+isChecked1);
	    Thread.sleep(2000);
	    el4.click();
	    isChecked1 = el4.getAttribute("checked");
	    System.out.println("Breakfast is checked? ="+isChecked1);
  }

  @Test
  public void sampleTest() throws InterruptedException {
    
    Views();
    Scroll();
    RadioButtons();
    
  }

  @After
  public void tearDown() {
    driver.quit();
  }
}

